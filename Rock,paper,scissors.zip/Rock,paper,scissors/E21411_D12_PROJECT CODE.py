from pyfirmata import Arduino, util, INPUT, OUTPUT
import time
import random

# Setup
port = 'COM3'  # Update with your port
board = Arduino(port)

# Constants for game
choices = ["Rock", "Paper", "Scissors", "Lizard", "Spock"]
choice_pins = [1, 2, 3, 4, 5]  # Analog pins for Rock, Paper, Scissors, Lizard, Spock
start_button = 0  # Analog pin for Start/End button
indicator_led = 11  # Pin for indicator LED
score_leds_human = [5, 6, 7]  # LEDs to represent human score in binary
score_leds_computer = [2, 3, 4]  # LEDs to represent computer score in binary
computer_choice_leds = [8, 9, 10]  # LEDs to represent computer choices in binary
buzzer = 12  # Buzzer pin

# Initialize iterator for analog inputs
it = util.Iterator(board)
it.start()

# Set up buttons to INPUT
for pin in choice_pins:
    board.analog[pin].mode = INPUT
board.analog[start_button].mode = INPUT

# Set up indicator LED to OUTPUT
board.digital[indicator_led].mode = OUTPUT

# Set up other LEDs to OUTPUT
for led in score_leds_human + score_leds_computer + computer_choice_leds:
    board.digital[led].mode = OUTPUT
board.digital[buzzer].mode = OUTPUT

# Variables for scores and rounds
player_score = 0
computer_score = 0
round_counter = 0
max_rounds = 7


def play_tone(duration):
    """Play a tone on the buzzer for a given duration."""
    board.digital[buzzer].write(1)
    time.sleep(duration)
    board.digital[buzzer].write(0)

def read_button(pin):
    """Read the state of a button connected to an analog pin."""
    value = board.analog[pin].read()
    if value is None:
        return False
    return value > 0.5  # Adjusted threshold for normalized value

def update_leds(value, leds):
    """Update LEDs to display a binary representation of a given value."""
    binary = format(value, '03b')
    for i, bit in enumerate(binary):
        board.digital[leds[i]].write(int(bit))
    

def display_computer_choice(choice):
    """Display the computer's choice on the LEDs by using binary representation."""
    choice_dict = {'Rock': 1, 'Paper': 2, 'Scissors': 3, 'Lizard': 4, 'Spock': 5}
    choice_value = choice_dict[choice]
    binary = format(choice_value, '03b')
    for i, bit in enumerate(binary):
        board.digital[computer_choice_leds[i]].write(int(bit))
    print("Computer Choice: ", choice)
    time.sleep(3)
    for led in computer_choice_leds:
        board.digital[led].write(0)

def get_winner(player_choice, computer_choice):
    """Determine the winner of a round."""
    wins = {
        'Rock': ['Scissors', 'Lizard'],
        'Paper': ['Rock', 'Spock'],
        'Scissors': ['Paper', 'Lizard'],
        'Lizard': ['Spock', 'Paper'],
        'Spock': ['Scissors', 'Rock']
    }
    if player_choice == computer_choice:
        return 0  # Tie
    elif computer_choice in wins[player_choice]:
        return 1  # Player wins
    else:
        return 2  # Computer wins

def game_round():
    """Play a single round of the game."""
    print("Press your choice")
    board.digital[indicator_led].write(1) #Turn on indicator Led.
    player_choice = None
    start_time = time.time()

    '''Get user input within 3 seconds.'''
    while time.time() - start_time < 3 :
        for i, pin in enumerate(choice_pins):
            time.sleep(0.05)
            if read_button(pin):
                player_choice = choices[i]
                break
        if player_choice:
            print("Player Choice: ", player_choice)
            #Turn off indicator LED before buzzer rings when choice was selected.
            board.digital[indicator_led].write(0) 
            time.sleep(0.2)
            break
    if not player_choice:
        print('Player choice not selected.')

    #Ring buzzer for 1 second.
    play_tone(1)
    time.sleep(0.2)
    #Turn off indicator after buzzer rings when choice was not selected.
    board.digital[indicator_led].write(0) 

    #Get a random choice from computer.
    computer_choice = random.choice(choices)
    display_computer_choice(computer_choice)
    
    #Return the player and computer choices and return the winner of the round.
    if not player_choice:
        return None, computer_choice, 2
    else:
        return player_choice, computer_choice, get_winner(player_choice, computer_choice)
    
def blink_leds(leds,Time=1):
    '''Blink the LEDs 3 times.'''
    for _ in range(3):
        for pin in leds:
            board.digital[pin].write(1)
        time.sleep(Time)
        for pin in leds:
            board.digital[pin].write(0)
        time.sleep(Time)
    
def tellWinner(computer_score, player_score, comLeds, playerLeds):
    '''Tell the winner of the game'''
    if computer_score > player_score:
        print('---Computer Wins---')
        for leds in playerLeds:
            board.digital[leds].write(0)
        blink_leds(comLeds)
    elif player_score > computer_score:
        print('---You Win---')
        for leds in comLeds:
            board.digital[leds].write(0)
        blink_leds(playerLeds)
    else:
        print('---You and computer are tied---')
        blink_leds(comLeds+playerLeds)


max_rounds = 7

# Wait for start button press to begin the game

while True:
    round_counter = 0
    player_score = 0
    computer_score = 0
    print('==============Rock Paper Scissors Lizard Spock==============')
    print('Press the button to start')
    while read_button(start_button) is False:
        time.sleep(0.05)
    print('-----Game Begins-----')



    play_tone(1)  # Play buzzer tone when game starts
    print("Game Started")  
    time.sleep(1)  


    while round_counter < max_rounds and (not read_button(start_button)):
        round_counter += 1
        print(f'-------------------------------Round {round_counter}-------------------------------')
        player_choice, computer_choice, winner = game_round()
        if winner == 1:
            player_score += 1
        elif winner == 2:
            computer_score += 1

        # Update score LEDs
        update_leds(player_score, score_leds_human)
        update_leds(computer_score, score_leds_computer)

        print(f'-------Score for round {round_counter} ---------')
        print("Player Score: ", player_score)
        print("Computer Score: ", computer_score)
        time.sleep(2)

    '''End of the Game'''
    play_tone(2)
    print("-----------------------Game Over---------------------")
    print(f"Final Score - Player: {player_score}, Computer: {computer_score}")
    update_leds(player_score, score_leds_human)
    update_leds(computer_score, score_leds_computer)
    time.sleep(2)
    print('-----------------------Winner------------------------')
    tellWinner(computer_score, player_score, score_leds_computer, score_leds_human)
    # Blink indicator LED 3 times to represent the END of the Game.
    blink_leds([indicator_led])